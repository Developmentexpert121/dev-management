<?php echo $__env->make('user::admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    <div class="main-panel">    
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Users</h4>
                  <p class="card-description">
                    New User Add
                  </p>    
                  <?php if(Session::has('message')): ?>
                    <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
                   <?php endif; ?>     
                  <form class="forms-sample" action='<?php echo e(url("admin/newuser")); ?>' method='post' enctype="multipart/form-data">
                            
                      <?php echo e(csrf_field()); ?>

                      
                    <div class="form-group">
                      <label for="exampleInputUsername1">Username</label>
                      <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="name" name='name' placeholder="Username">
                      <?php if($errors->has('name')): ?>
                      <div class="error"><?php echo e($errors->first('name')); ?></div>    
                      <?php endif; ?>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Email address</label>
                      <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" name='email' placeholder="Email">
                      <?php if($errors->has('email')): ?>
                      <div class="error"><?php echo e($errors->first('email')); ?></div>
                      <?php endif; ?>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Password</label>
                      <input type="password" class="form-control" value="<?php echo e(old('password')); ?>" id="password"  name='password' placeholder="Password">
                      <?php if($errors->has('password')): ?>
                      <div class="error"><?php echo e($errors->first('password')); ?></div>
                      <?php endif; ?>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">Confirm Password</label>
                      <input type="password" class="form-control"  value="<?php echo e(old('password_confirmation')); ?>"  id="password_confirmation" name='password_confirmation'  placeholder="Password">
                      <?php if($errors->has('password_confirmation')): ?>
                      <div class="error"><?php echo e($errors->first('password_confirmation')); ?></div>
                      <?php endif; ?>
                    </div>
                    
                      
                    <div class="form-group">
                      <label for="exampleInputConfirmPassword1">User Role</label>

                        <select name="user_role" id="cars" class="form-control" >
                        <option value="">Please Select User Role</option>
                          <option value="1" <?php if(old('user_role') == '1'){ echo 'selected'; } ?>>Team Leader</option>
                          <option value="2" <?php if(old('user_role') == '2'){ echo 'selected'; } ?>>Employee</option>
                          <option value="3" <?php if(old('user_role') == '3'){ echo 'selected'; } ?>>Manager</option>
                          <option value="4" <?php if(old('user_role') == '4'){ echo 'selected'; } ?> >Hr</option>
                        </select>
                        <?php if($errors->has('user_role')): ?>
                      <div class="error"><?php echo e($errors->first('user_role')); ?></div>
                      <?php endif; ?>
                    </div> 

                    <div class="form-group">
                     <input type="file" name="image" >
                     <?php if($errors->has('image')): ?>
                      <div class="error"><?php echo e($errors->first('image')); ?></div>
                      <?php endif; ?>
                    </div>

                     
                    <button type="submit" class="btn btn-primary me-2">Submit</button>

                  </form>
 
                </div>
              </div>
              </div>     
            </div>
          </div>       
        
          <?php echo $__env->make('user::admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
</div>
</div>
           
        

            <?php /**PATH /opt/lampp/htdocs/dev-management/Modules/User/Resources/views/admin/user.blade.php ENDPATH**/ ?>