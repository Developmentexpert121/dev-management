<?php echo $__env->make('projects::admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-panel">    
  <div class="content-wrapper">
    <div class="row">
      <div class="col-md-6"><h4>Project</h4></div>
      <div class="col-md-6"><?php echo e($project_data->name); ?></div>
    </div>
    <div class="row">
      <div class="col-md-6"><h4>Key</h4></div>
      <div class="col-md-6"><?php echo e($project_data->key); ?></div>
    </div>
  </div>
</div>
<?php echo $__env->make('projects::team.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dev-management/Modules/Projects/Resources/views/single.blade.php ENDPATH**/ ?>