<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href='<?php echo e(url("dashboard")); ?>'>
              <i class="mdi mdi-grid-large menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
        </ul>
</nav> <?php /**PATH /opt/lampp/htdocs/dev-management/Modules/User/Resources/views/tl/sidebar.blade.php ENDPATH**/ ?>