<?php echo $__env->make('projects::team.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Sprint Form</h4>
                  <p class="card-description">
                    Create Sprint
                  </p> 

  <div class="main-panel">  
 <!--  <a href='<?php echo e(url("admin/project/team/createissue/{$project_id}")); ?>'><button type="button" class="create_button"> Create Task</a> </button> 
<button type="button" class="create_button" id="sprint_button"> Create Sprint</button></a> -->
        <div id="all_sprints" class="all_sprints" >

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>  
    <?php endif; ?>
 
        <form method="post" action="<?php echo e(url('admin/project/team/save_sprint')); ?>"> 

        <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
        <input type="hidden" name="project_id" value="<?php echo e($project_id); ?>">
        Sprint Name <input type="text" name="sprint_name" value=""><br><br>
        Duration:<select name="duration" >
           <option value="">Please Select Duration</option>
           <option value="1">1week</option>
           <option value="2">2week</option>
           <option value="3">3week</option>
           <option value="4">Custom</option>
      </select>
      <br><br>

       Start date:<input type="date" name="start_date">
       <br><br>

       End date:<input type="date" name="end_date" >
       <br><br>

       Sprint goal:
      <textarea name="sprint_goal" rows="4" cols="50"></textarea>
      <br><br>

      <input type="submit" name="" value="Start Sprint">

   </form>
   </div>  
   </div> 
   </div> 
   </div> 
   </div> 

    
           
  <form method="post" action="<?php echo e(url('admin/project/team/save_sprint')); ?>"> 

    <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
    <input type="hidden" name="project_id" value="<?php echo e($project_id); ?>">
   Sprint Name <input type="text" name="sprint_name" value=""><br><br>
   Duration:<select name="duration" >
    <option value="1">1week</option>
    <option value="2">2week</option>
    <option value="3">3week</option>
    <option value="4">Custom</option>
   </select><br><br>
   Start date:<input type="date" name="start_date"><br><br>
   End date:<input type="date" name="end_date" ><br><br>
   Sprint goal:
   <textarea name="sprint_goal" rows="4" cols="50"></textarea>
  <br><br>
   <input type="submit" name="" value="Start Sprint">

   </form>
   </div>  


    <div class="row"> 
                      <div class="col-lg-8 d-flex flex-column">
                        <div class="row flex-grow">
                          <div class="col-12 col-lg-4 col-lg-12 grid-margin stretch-card">
                            <div class="card card-rounded">
                              <div class="card-body">
                                <div class="d-sm-flex justify-content-between align-items-start">
                                  <div>
                                   <h4 class="card-title card-title-dash"></h4>
                                   <h5 class="card-subtitle card-subtitle-dash"></h5>
                                  </div>
                                  <div id="performance-line-legend"></div>
                                </div>
                                <div class="chartjs-wrapper mt-5">
                                  <!-- <canvas id="performaneLine"></canvas> -->
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> 
                      </div>
                      <div class="col-lg-4 d-flex flex-column">
                        <div class="row flex-grow">
                          <div class="col-md-6 col-lg-12 grid-margin stretch-card">
                            <div class="card bg-primary card-rounded">
                              <div class="card-body pb-0">
                                <h4 class="card-title card-title-dash text-white mb-4"></h4>
                                <div class="row">
                                  <div class="col-sm-4">
                                    <p class="status-summary-ight-white mb-1"></p>
                                    <h2 class="text-info"></h2>
                                  </div>
                                  <div class="col-sm-8">
                                    <div class="status-summary-chart-wrapper pb-4">
                                      <canvas id="status-summary"></canvas>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>    
                          <div class="col-md-6 col-lg-12 grid-margin stretch-card">
                            <div class="card card-rounded">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-sm-6">
                                    <div class="d-flex justify-content-between align-items-center mb-2 mb-sm-0">
                                      <!-- <div class="circle-progress-width">
                                        <div id="totalVisitors" class="progressbar-js-circle pr-2"></div>
                                      </div> -->
                                      <div>
                                        <p class="text-small mb-2"></p>
                                        <h4 class="mb-0 fw-bold"></h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-6">
                                    <div class="d-flex justify-content-between align-items-center">
                                     <!--  <div class="circle-progress-width">
                                        <div id="visitperday" class="progressbar-js-circle pr-2"></div>
                                      </div> -->
                                      <div>
                                        <p class="text-small mb-2"></p>
                                        <h4 class="mb-0 fw-bold"></h4>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
    <?php echo $__env->make('projects::team.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dev-management/Modules/Projects/Resources/views/team/Sprintview.blade.php ENDPATH**/ ?>