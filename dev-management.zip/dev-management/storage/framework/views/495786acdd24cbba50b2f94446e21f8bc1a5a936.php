<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href='#'>
              <i class="mdi mdi-grid-large menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href='#'>
              <i class="mdi mdi-grid-large menu-icon"></i>
              <span class="menu-title">Active Sprints</span>
            </a>
          </li>

         
        </ul>
      </nav><?php /**PATH /opt/lampp/htdocs/dev-management/Modules/Projects/Resources/views/company/sidebar.blade.php ENDPATH**/ ?>