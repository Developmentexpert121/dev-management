<?php echo $__env->make('projects::admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-panel">    
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-6">
                <a href='<?php echo e(url("admin/project/template")); ?>'><button class="cr_btn">Create Project</button></a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <?php if(Session::has('message')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
                        <?php endif; ?>
                        <table id="projects_table" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Name</th>
                                    <th>key</th>
                                    <th>Created by</th>
                                    <th>Template</th>
                                    <th>Project Type</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i=1;
                                foreach($project_list as $data){
                                    if($data->template==1){
                                        $templatename='Kanban';
                                    }elseif($data->template==2){
                                        $templatename='Scrum'; 
                                    }elseif($data->template==3){
                                        $templatename='Bug';
                                    }

                                    if($data->project_type==1){
                                        $project_type='Team';
                                        $project_name = 'team';
                                    }else{
                                        $project_type='Company';
                                        $project_name = 'company';
                                    }
                                    ?>
                                    <tr> 
                                        <td><?php echo $i++  ?></td> 
                                        <td><a href='<?php echo e(url("admin/project/{$project_name}/{$data->id}")); ?>'><?php echo ucfirst($data->name);  ?></a></td>
                                        <td><?php echo ucfirst($data->key) ; ?></td>
                                        <td><?php echo ucfirst($data->username) ; ?></td> 
                                        <td><?php echo $templatename ; ?></td>
                                        <td><?php echo $project_type ;?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Name</th>
                                    <th>key</th>
                                    <th>Created by</th>
                                    <th>Template</th>
                                    <th>Project Type</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
    .cr_btn { -webkit-box-align: center; align-items: center; border-width: 0px; border-radius: 3px; box-sizing: border-box; display: flex; font-size: inherit; font-style: normal; font-family: inherit; font-weight: 500; max-width: 100%; position: relative;    text-align: center; text-decoration: none; transition: background 0.1s ease-out 0s, box-shadow 0.15s cubic-bezier(0.47, 0.03, 0.49, 1.38) 0s; white-space: nowrap; background: rgb(9 147 20); color: rgb(255, 255, 255); cursor: pointer; height: 48px;    line-height: 40px; padding: 0px 10px; vertical-align: middle; width: 420px; -webkit-box-pack: center; justify-content: center;outline: none;  margin: 0px 0px 6px; }
    a , a:hover { text-decoration: none; }
</style>
<?php echo $__env->make('projects::admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dev-management/Modules/Projects/Resources/views/admin/datatable.blade.php ENDPATH**/ ?>