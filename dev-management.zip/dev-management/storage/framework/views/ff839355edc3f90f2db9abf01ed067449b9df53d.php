

<?php echo $__env->make('projects::header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-panel">    
  <div class="row" > 
    <div class="col-md-12">
      <a href='<?php echo e(url("admin/project/scrum/team_management")); ?>'> 
        <h4  algin='center'>Team Management</h4> 
      </a>
    </div> 
  </div>
  
  <div class="row">
    <div class="col-md-12">
      <a href='<?php echo e(url("admin/project/scrum/company_management")); ?>'>  
        <h4  algin='center'>Company Management</h4> 
      </a>
    </div>  
  </div>
</div><?php /**PATH /opt/lampp/htdocs/dev-management/Modules/Projects/Resources/views/scrum_template.blade.php ENDPATH**/ ?>